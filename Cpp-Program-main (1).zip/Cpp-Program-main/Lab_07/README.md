# Practical Lab Assignment

1. Calculate the x^y (power) using recursion.
2. Find sum of natural numbers using recursion.
3. Display Fibonacci Series Using Recursion.
4. Find G.C.D for two integers using recursion.