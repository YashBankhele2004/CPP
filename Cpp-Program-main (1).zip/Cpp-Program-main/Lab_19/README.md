# Practical Lab Assignment - File Handling

1. Create two file “one.txt” and “two.txt” which contains first 10 even numbers and first ten multiples of 5 respectively; Read the two files, find the sum of all the number of these two files and store it in the variable TOTAL. Write this value in third file named “total.txt”.

2. A  file contains a  list of telephone numbers in the following form:
    ```
    John    23456
    Ahmed	9876
    ...     ...
    ```
    The names contain only one word and the names and telephone numbers are separated by white spaces. Write a program to read the file and output the list in the two columns.

3. Enter 20 numbers in a file named “Numbers.txt”. Ask user to enter any number and search if it exists in the file or not.
