# Practical Lab Assignment - Control Structures - Loop/Switch

1. Program to calculate sum of numbers from m to n.
    - Hint: Input two numbers m and n. Find sum of all numbers from m to n. For example m=3 and n=8 then sum will be 3 + 4 + 5 + 6 + 7 + 8 = 33.
2. Program to print Fibonacci series up to 100. 
    - Hint: Fibonacci Series is 1, 1, 2, 3, 5, 8, 13, 21, ....
3. Program to input a number and then calculate sum of its digits.
    - Hint: let number = 562. Then you should print 5 + 6 + 2 = 13.
4. Program to find whether given number is a prime number or not.
5. Program to display sum of series 1 + 1/2 + 1/3 + ... + 1/n.
6. Program to display series and find sum of 1 + 3 + 5 + ... + n.
7. Program to use switch statement. Display Monday to Sunday.
8. Program to display arithmetic operator using switch case