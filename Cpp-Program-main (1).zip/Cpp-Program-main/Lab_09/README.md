# Practical Lab Assignment - Arrays

1. Write a program to generate Pascal’s triangle.
    ```
            1
           1 1
          1 2 1
         1 3 3 1
        1 4 6 4 1
      1 5 10 10 5 1
    1 6 15 20 15 6 1
    ```
2. Write a menu driven program to read and display an m × n matrix. Also find the sum, transpose and product of two m × n matrices.
3. In a small company there are five salesman. Each salesman is supposed to sell three products. Write a program using 2D array to print the total sales by each salesman and total sales of each item.