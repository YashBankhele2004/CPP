# Practical Lab Assignment - File Handling Operations

Create a class Person with two private members name and telephone number

Write a program that will create a data file containing name and telephone numbers of person. Use a class object to store each set of data. Read the file contents and display it on screen.
- Write an interactive menu driven program that will access the file created in program no. 1 and implement the following tasks:
- Determine the telephone number of the specified person.
- Determine the name if telephone number is known.
- Delete a record.
- Add a record to a specific position.
