# Practical Lab Assignment - Control Structure - Nested Loop

1. Program to print stars Sequence1.
    ```
    *
    **
    ***
    ****
    *****
    ```
2. Program to print stars Sequence2.
    ```
        *
       ** 
      ***
     ****
    *****
    ```
3. Program to print star Sequences3.
    ```
      *
     ***
    *****
    ```
4. Program to print Sequence4.
    ```
    *
    **
    ***
    ****
    *****
    *****
    ****
    ***
    **
    *
    ```
5. Write a program to add first seven terms of the following series using for loop: `1/!1+ 2/!2 + 3/!3 + ...`