# Practical Lab Assignment

```
1. Write a program to calculate area of following figures using function overloading:
Circle
Rectangle
Triangle
Square
(Hint: 1. create 4 functions with same name area. 2. Each function to calculate area of one figure.)

2. Write a program to calculate circumference of the following figures using function overloading:
Circle
Rectangle
Triangle
Square

3. Write a program using function overloading:
To find largest among three integers.
To find largest among three floating point numbers.

4. Convert function template for problem 3.
```