// Program to print text on the console.
// cout -> console output.

#include <iostream>

using namespace std;

int main()
{
    cout << "Hello, World!" << endl;
    system("pause");
    return 0;
}