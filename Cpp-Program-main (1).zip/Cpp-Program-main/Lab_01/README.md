# Practical Lab Assignment - Variables/Operators

1. C++ Program to print "Hello, World!".
2. C++ Program to print an integer entered by the user.
3. C++ Program to Add/Subtract/Multiply/Divide Two Integers.
4. C++ Program to Add/Subtract/Multiply/Divide Two Integers entered by the user.
5. C++ Program to Add/Subtract/Multiply/Divide two Floating Point Numbers.
6. C++ Program to Compute Quotient and Remainder.
7. C++ Program to Calculate the Area and Circumference of a Circle.
8. C++ Program to Calculate the Area of a Scalene Triangle.
9. C++ Program to Calculate the Area of an Equilateral Triangle.
10. C++ Program to Calculate the Area of Right Angle Triangle.
11. C++ Program to Calculate the Area and Perimeter of a Rectangle.
12. C++ Program to Calculate the Area and Perimeter of a Square.
13. C++ Program to Find ASCII Value of a Character.
14. C++ Program to Find the Size of int, float, double, and char.
15. C++ Program to Swap Two Numbers.
