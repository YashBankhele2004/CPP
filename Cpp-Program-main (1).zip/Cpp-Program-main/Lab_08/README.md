# Practical Lab Assignment - Arrays

1. Write a program to display an array.
2. Write a program to find average of array elements.
3. Write a program to merge to sorted arrays.
    ```
    a1[10] = [25, 27, 32, 98]
    a2[10] = [12, 23, 28, 51, 72, 85, 97]
    then a3[20] should be equal to = [12, 23, 25, 27, 28, 32, 51, 72, 85, 97, 98]
    ```
4. Write a program to insert an element to an array.
5. Write a program to delete an element from an array.