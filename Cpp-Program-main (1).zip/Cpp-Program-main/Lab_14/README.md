# Practical Lab Assignment - Binary Operator Overloading

### Program 1
```
Create a class Rectangle.
Private members of class Rectangle: Length, breadth.
Create Member function: 
    Public:
        double getArea()
        void setLength(double)
        void setBreadth(double)
```
Declare overloading function use **(+)** operator to add two Rectangle objects.
In the `main()` function set rectangle length, breadth with member functions and use area function to print area of each rectangle. 
Then declare a third object use overloading function to get area of third object.

### Program 2
```
Create a class Distance.
Private members of class Distance: Kilometer, meter.
Create default constructor and parameter constructor.
Create Member function: 
    void showDistance()
```
Declare overloading function use **(==)** operator to compare two distances. 
In the `main()` function set Distance  kilometer, meter and use show distance to print of each distance.
Then use overloading function to get difference of two distances.
